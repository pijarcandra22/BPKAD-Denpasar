-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 12, 2022 at 05:14 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `id_p` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `instansi` varchar(100) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pasword` varchar(255) DEFAULT NULL,
  `role` varchar(20) NOT NULL,
  `foto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`id_p`, `nama`, `instansi`, `nip`, `email`, `pasword`, `role`, `foto`) VALUES
(8, 'widya', 'Perencanaan Anggaran', '1908561015', 'widya@gmail.com', '111', 'pegawai', '1665582294.jpg'),
(9, 'pino', 'Pemberdarahaan Akuntansi dan Pelaporan', '1908561108', 'pino@gmail.com', '222', 'pegawai', '1665582249.jpg'),
(10, 'hatake', 'Pengelolaan BMD', '1908561001', 'hatake@gmail.com', '333', 'pegawai', 'profil.png'),
(11, 'sasuke', 'Sekertariat BPKAD', '1908561002', 'sasuke@gmail.com', '444', 'pegawai', 'profil.png'),
(12, 'sakura', 'BPKAD', '1908561100', 'sakura@gmail.com', '101010', 'admin', 'profil.png');

-- --------------------------------------------------------

--
-- Table structure for table `pertanyaan`
--

CREATE TABLE `pertanyaan` (
  `id_q` int(11) NOT NULL,
  `id_p` int(11) NOT NULL,
  `pertanyaan` text NOT NULL,
  `jawaban` text NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  `tujuan` varchar(50) DEFAULT NULL,
  `penanya` varchar(100) DEFAULT NULL,
  `penjawab` varchar(100) DEFAULT NULL,
  `file_jawaban` varchar(100) DEFAULT NULL,
  `instansi` varchar(50) DEFAULT NULL,
  `id_penjawab` varchar(10) DEFAULT NULL,
  `rating` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_p`);

--
-- Indexes for table `pertanyaan`
--
ALTER TABLE `pertanyaan`
  ADD PRIMARY KEY (`id_q`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id_p` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `pertanyaan`
--
ALTER TABLE `pertanyaan`
  MODIFY `id_q` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
