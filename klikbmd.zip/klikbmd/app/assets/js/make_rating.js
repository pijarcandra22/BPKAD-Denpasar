//fungsi penentuan rating
function rating(idq,star){
    if($(".star_"+star+""+idq).css("color") != "rgb(255, 255, 0)"){
      for(let i = 1; i<=star; i++){
        $(".star_"+i+""+idq).css("color","yellow");
      }
    }else{
      for(let i = star; i<=5; i++){
        $(".star_"+i+""+idq).css("color","rgb(193, 64, 64)");
      }
    }
    $.ajax({
      url: baseurl+"/Pertanyaan/rating/"+idq+"/"+star,
      data: {idq : idq,rating : star},
      method: 'post',
    });
  }