const baseurl = "http://localhost/klikbmd";
//fungsi back home
function home(){
  window.location.href = baseurl+"/";
}

//fungsi cari perbidang
function cari_bidang(bidang){
  $.ajax({
    url: baseurl+'/Master/get_pegawai_bidang',
    data: {bidang : bidang},
    method: 'post',
    success: function(data){
      $("#belum_jawab").html(data);
    }
  })
}

//fungsi cari pegawai
function cari_pegawai(keyword){
  if(keyword === ""){
    $.ajax({
      url: baseurl+'/Master/get_pegawai_all',
      success: function(data){
        $("#belum_jawab").html(data);
      }
    })
  }else{
    $.ajax({
      url: baseurl+'/Master/get_pegawai_all',
      data: {keyword : keyword},
      method: 'post',
      success: function(data){
        $("#belum_jawab").html(data);
      }
    })
  }
}

$(".pegawaiprofil").on("click", function(){
  const idprofil = $(this).data("id");
  $.ajax({
    url: baseurl+'/Master/get_profil',
    data: {idprofil : idprofil},
    method: 'post',
    dataType: 'json',
    success: function(data) {
      $("#namaprofil").val(data.nama);
      $("#instansiprofil").val(data.instansi);
      $("#emailprofil").val(data.email);
      $("#img_user_label").css("background-image","url("+baseurl+"/app/assets/image/"+data.foto+")")
    }
  });
})