const domain = document.getElementById('domain');
const target = document.getElementById('floatingTextarea2');
const baseurl  = "http://localhost/klikbmd";
  $(document).ready(function() {
    $("<div/>").load(baseurl+"/Home/component/form_sign").appendTo("body");
    $("#bar_question").append($('<div>').load(baseurl+"/Home/component/question_pop"));
    $(".formnojawab").on('click', function(){
      var id = $(this).data('id');
      $.ajax({
        url: baseurl+'/Home/get_idp',
        data: {id : id},
        method: 'post',
        dataType: 'json',
        success: function(data) {
          $("#identitas").html(data.penanya+" - "+data.instansi);
          $("#pertanyaan").html(data.pertanyaan);
          if(data.file != ""){
            $("#pertanyaan").html(data.pertanyaan+"<br><a href='"+baseurl+"/Assets/upload/"+data.file+"' target='blank'>files</a>");
          }
          $("#id_question").val(data.id_q);
          if(data.jawaban != ""){
            set_text(data.jawaban);
          }
          if(data.file_jawaban != ""){
            $("#container_file_jawab").html("<a href='"+baseurl+"/Assets/upload/"+data.file_jawaban+"' target='blank'>files</a>").attr({"class":"input-group-text"});
            $("#container_file_jawab").css({"display":"block"});
          }
        }
      });
    });
  });
  //fungsi hapus
  function hapusjawaban(idq){
    if(confirm("yakin ingin menghapus?")){
      window.location.href = baseurl+"/Pertanyaan/hapus/"+idq;
    }
  }
  //fungsi edit jawaban
  function editjawaban(idq){
    $.ajax({
      url: baseurl+'/Home/get_idp',
      data: {id : idq},
      method: 'post',
      dataType: 'json',
      success: function(data) {
        $("#identitas").html(data.penanya+" - "+data.instansi);
        $("#pertanyaan").html(data.pertanyaan);
        if(data.file != ""){
          $("#pertanyaan").html(data.pertanyaan+"<br><a href='"+baseurl+"/Assets/upload/"+data.file+"' target='blank'>files</a>");
        }
        $("#id_question").val(data.id_q);
        if(data.jawaban != ""){
          set_text(data.jawaban);
        }
        if(data.file_jawaban != ""){
          $("#container_file_jawab").html("<a href='"+baseurl+"/Assets/upload/"+data.file_jawaban+"' target='blank'>files</a>").attr({"class":"input-group-text"});
          $("#container_file_jawab").css({"display":"block"});
        }
      }
    });
  }
  //cari pertanyaan
  function caripertanyaan(keyword,bidang){
    if(keyword === ""){
      $.ajax({
        url: baseurl+'/Pertanyaan/cari',
        success: function(data){
          $("#bar_question").html(data);
        }
      })
    }else{
      $.ajax({
        url: baseurl+'/Pertanyaan/cari',
        data: {keyword : keyword, bidang : bidang},
        method: 'post',
        success: function(data){
          $("#bar_question").html(data);
        }
      })
    }
  }
  //fungsi edit textarea
  function set_text(text,file){
    target.value = text;
  }