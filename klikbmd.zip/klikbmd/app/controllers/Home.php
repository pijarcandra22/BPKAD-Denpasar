<?php
session_start();
class Home extends Controller {
	public function index()
	{
		if(isset($_SESSION["login"])){
			$data["profil"] = $this->model("Home_model")->get_profil($_SESSION["id_p"]);
			if($_SESSION["role"] === "penanya"){
				$data["title_question"] = "Pertanyaan Saya";
			}else if($_SESSION["role"] === "pegawai"){
				$data["title_question"] = "Questions For ".$data["profil"]["instansi"];
				$data["pertanyaan"] = $this->model("Home_model")->get_pertanyaan_by_bidang($data["profil"]["instansi"]);
			}else{
				$data["title_question"] = "Frequently Asked Questions";
			}
		}else{
			$data["title_question"] = "Frequently Asked Questions";
		}
		$data['js'] = 'load';
		$this->view('templates/header', $data);
		$this->view('Home/home', $data);
		$this->view('templates/footer', $data);
	}
	public function component($component=[])
	{
		if(empty($component)){
			echo "<script>
            window.location.href = '".BASEURL."'
            </script>";
			return false;
		}
		if(isset($_SESSION["login"])){
			$data["profil"] = $this->model("Home_model")->get_profil($_SESSION["id_p"]);
			if($_SESSION["role"] === "penanya"){
				$data["pertanyaan"] = $this->model("Home_model")->get_pertanyaan_by_from($_SESSION["id_p"]);
			}else if($_SESSION["role"] === "pegawai"){
				$data["pertanyaan"] = $this->model("Home_model")->get_pertanyaan_by_bidang($data["profil"]["instansi"]);
			}else{
				$data["pertanyaan"] = $this->model("Pertanyaan_model")->get_faq();
			}
		}else{
			$data["pertanyaan"] = $this->model("Pertanyaan_model")->get_faq();
		}
		$this->view('components/'.$component, $data);
	}
	public function ubah()
	{
		if(!isset($_SESSION["login"])){
			echo "<script>
					window.location.href = '".BASEURL."'
					</script>";
			return false;
		}
		if($this->model("Home_model")->ubah_profil($_POST,$_FILES) > 0){
			echo "<script>
            window.location.href = '".BASEURL."'
            </script>";
		}else{
			echo "<script>
            window.location.href = '".BASEURL."'
            </script>";
		}
	}
	public function cek_session()
	{
		if(!isset($_SESSION["login"])){
			echo "<script>
					window.location.href = '".BASEURL."'
					</script>";
			return false;
		}
		if(isset($_SESSION["login"])){
			echo "sudah";
		}else{
			echo "belum";
		}
	}
	public function get_idp()
	{
		if(!isset($_SESSION["login"])){
			echo "<script>
					window.location.href = '".BASEURL."'
					</script>";
			return false;
		}
		echo json_encode($this->model("Home_model")->get_id_Pertanyaan($_POST["id"]));
	}
}

?>