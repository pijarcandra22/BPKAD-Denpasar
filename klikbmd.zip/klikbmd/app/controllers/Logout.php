<?php
session_start();
if(!isset($_SESSION["login"])){
    echo "<script>
            window.location.href = '".BASEURL."'
            </script>";
    return false;
}

class Logout extends Controller {
    public function index()
    {
        session_destroy();
        unset($_SESSION);
        echo "<script>
            window.location.href = '".BASEURL."'
            </script>";
    }
}