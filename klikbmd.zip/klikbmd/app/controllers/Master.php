<?php
session_start();
if(!isset($_SESSION["login"])){
    echo "<script>
            window.location.href = '".BASEURL."'
            </script>";
    return false;
}
class Master extends Controller {
    public function index()
    {
        $data["rating"] = $this->model("Pegawai_model")->get_rating_per_bidang();
        $data["pegawai"] = $this->model("Master_model")->get_all_pegawai();
        $data["performa"] = $this->model("Pegawai_model")->performa();
        $data["perbidang"] = $this->model("Pegawai_model")->perbidang();
        $data["bidang"] = ["Perencanaan Anggaran","Pemberdarahaan Akuntansi dan Pelaporan","Pengelolaan BMD","Sekertariat BPKAD"];
        $data['css'] = "admin";
        $data['js'] = "admin";
        $this->view('templates/header', $data);
        $this->view("admin/admin", $data);
        $this->view('templates/footer', $data);
    }
    public function get_pegawai_bidang()
    {
        $data["cari_bidang"] = $this->model("Pegawai_model")->cari_bidang($_POST);
        $this->view('helpers/cari_bidang', $data);
    }
    public function get_pegawai_all()
    {
        if(isset($_POST["keyword"])){
            $data["caripegawai"] = $this->model("Pegawai_model")->cari_pegawai($_POST["keyword"]);
        }else{
            $data["caripegawai"] = $this->model("Master_model")->get_all_pegawai();
        }
        $this->view("helpers/cari_pegawai", $data);
    }
    public function get_profil(){
        echo json_encode($this->model("Pegawai_model")->profil($_POST));
    }

}