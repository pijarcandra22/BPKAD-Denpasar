<?php
session_start();
if(!isset($_SESSION["login"])){
    echo "<script>
            window.location.href = '".BASEURL."'
            </script>";
    return false;
}
class Pertanyaan extends Controller {
    public function index()
    {
	    $this->view('helpers/eror');
    }
    public function create()
    {
        if($this->model("Pertanyaan_model")->create($_POST,$_FILES) > 0){
			echo "<script>
            window.location.href = '".BASEURL."'
            </script>";
		}else{
			echo "<script>
            window.location.href = '".BASEURL."'
            </script>";
		}
    }
    public function jawab()
    {
        if($this->model("Pertanyaan_model")->jawab($_POST,$_FILES) > 0){
			echo "<script>
            window.location.href = '".BASEURL."'
            </script>";
		}else{
			echo "<script>
            window.location.href = '".BASEURL."'
            </script>";
		}
    }
    public function Hapus($idq)
    {
        if($this->model("Pertanyaan_model")->hapus_jawaban($idq) > 0){
			echo "<script>
            alert('berhasil menghapus');
            window.location.href = '".BASEURL."'
            </script>";
		}else{
			echo "<script>
            alert('gagal menghapus');
            window.location.href = '".BASEURL."'
            </script>";
		}
    }
    public function rating()
    {
        echo $this->model("Pertanyaan_model")->update_rating($_POST);
    }
    public function cari()
    {
        $data["pertanyaan"] = $this->model("Pertanyaan_model")->cari_pertanyaan($_POST);
        $this->view('helpers/cari_pertanyaan', $data);
    }
}