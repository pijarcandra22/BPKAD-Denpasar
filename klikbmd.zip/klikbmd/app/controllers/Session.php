<?php
session_start();
if(isset($_SESSION["login"])){
    echo "<script>
            window.location.href = '".BASEURL."'
        </script>";
    return false;
}
class Session extends Controller {
    public function index()
    {   $data_sesion = $this->model('Session_model')->login($_POST);
        if(!empty($data_sesion)){
            $_SESSION["id_p"] = $data_sesion["id_p"];
            $_SESSION["role"] = $data_sesion["role"];
            $_SESSION["login"] = TRUE;
            echo "<script>
            window.location.href = '".BASEURL."'
            </script>";
        }else{
            echo "<script>
            alert('username atau password salah');
            window.location.href = '".BASEURL."'
            </script>";
        }
    }
}