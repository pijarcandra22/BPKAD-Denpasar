<?php

class Signup extends Controller {
    public function index()
    {
		$this->view('helpers/eror');
    }
    public function daftar()
    {
        if($this->model('Signup_model')->tambah_pengguna($_POST) > 0){
            echo "<script>
            alert('Berhasil Registrasi');
            window.location.href = '".BASEURL."'
            </script>";
        }else{
            echo "<script>
            alert('Berhasil Registrasi');
            window.location.href = '".BASEURL."'
            </script>";
        }
    }
}