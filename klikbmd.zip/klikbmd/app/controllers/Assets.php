<?php
session_start();
if(!isset($_SESSION["login"])){
    echo "<script>
            window.location.href = '".BASEURL."'
            </script>";
    return false;
}

class Assets extends Controller {
    public function index()
    {
		$this->view('helpers/eror');
    }
    public function upload($file)
    {
        $data["tipe"] = explode('.',$file);
        $data["tipe"] = end($data["tipe"]);
        $data["src"] = $file;
        $this->view('files/assets', $data);
    }
}