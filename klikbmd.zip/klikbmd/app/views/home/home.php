  <div style="text-align: center;" >
    <?php if(!isset($_SESSION["login"])){?>
    <img src="<?=ASSETS?>/image/kop-logo2.png" style="padding: 10px 41px; width: 400px" alt="">
    <div style="width:100%; display:flex; justify-content: center;">
      <div class="wakotImage"></div>
    </div>
    <h1 class="judulHome">Klinik Keuangan BMD</h1>
    <h4 style="font-family: Roboto;">Vasudhaiva Kutumbakam</h4>
    <p style="padding: 20px 20%; background-color:#c14040cb; color:#fff">
      Visi<br>
      Kota Kreatif Berbasis Budaya Menuju Denpasar Maju<br><br>
      Misi<br>
      Kejujuran dan spirit Sewaka Dharma sebagai penguat reformasi birokrasi menuju tata kelola pemerintahan yang baik (Good Governance)
    </p>
    <?php }?>
  </div>

  <div class="container-fluid">
    <!-- container main content -->
    <div class="row justify-content-center">
      <?php if(isset($_SESSION["role"]) && $_SESSION["role"] === "pegawai"){?>
      <div class="offcanvas offcanvas-start pt-md-4 ps-0 pe-0" tabindex="-1" id="leftbar">
        <img src="<?=ASSETS?>/image/kop-logo.png" style="padding: 10px 41px; width:100%" alt="">
        <h5 style="width: 100%; background:#C14040;padding:10px; color:#fff; text-align:center; font-family:Grand Hotel">Pertanyaan Belum Terjawab</h5>
        <div id="belum_jawab" style="height: 33%; margin:10px" class="vertical-scroll">
          <?php foreach($data["pertanyaan"] as $p_b):?>
          <?php if($p_b["jawaban"] === ""){?>
          <div data-bs-target="#formJawaban" data-bs-toggle="modal" class="formnojawab" data-id="<?=$p_b["id_q"]?>">
            <div style="display: flex; margin: 10px 30px" class="tab_list" id="list_ask">
              <p class="num_or_img">
                <img src="<?=ASSETS?>/image/<?=$data["profil"]["foto"]?>" alt="gambar" style="width: 100%; height: 100%; border-radius: 50%;">
              </p>
              <div style="display: block; padding-left:10px">
                <p style="font-size: 17px; line-height: 20px; margin:0" class="nama"><?=$p_b["penanya"]?></p>
                <p style="font-size: 10px; line-height: 13px; margin:0" class="ins_or_bidang"><?=$p_b["instansi"]?></p>
              </div>
            </div>
          </div>
          <?php };?>
          <?php endforeach;?>
        </div>
        <h5 style="width: 100%; background:#C14040;padding:10px; color:#fff; text-align:center; font-family:Grand Hotel">Pertanyaan Sudah Terjawab</h5>
        <div id="sudah_jawab" style="height: 33%; margin:10px" class="vertical-scroll">
          <?php foreach($data["pertanyaan"] as $p_b):?>
          <?php if($p_b["jawaban"] != ""){?>
            <div data-bs-target="#formJawaban" data-bs-toggle="modal" class="formnojawab" data-id="<?=$p_b["id_q"]?>">
            <div style="display: flex; margin: 10px 30px" class="tab_list" id="list_ask">
              <p class="num_or_img">
                <img src="<?=ASSETS?>/image/<?=$data["profil"]["foto"]?>" alt="gambar" style="width: 100%; height: 100%; border-radius: 50%;">
              </p>
              <div style="display: block; padding-left:10px">
                <p style="font-size: 17px; line-height: 20px; margin:0" class="nama"><?=$p_b["penanya"]?></p>
                <p style="font-size: 10px; line-height: 13px; margin:0" class="ins_or_bidang"><?=$p_b["instansi"]?></p>
              </div>
            </div>
            </div>
          <?php };?>
          <?php endforeach;?>
        </div>
      </div>
      <?php };?>

      <!-- main -->
      <div class="position-relative col-md-7 col-12" id="main_content">
        <!-- navbar -->
        <nav class="navbar fixed-md-top">
          <div class="container-fluid" style="padding: 20px 65px;">
            <div class="d-flex" style="width: 100%;">
              <?php if(isset($_SESSION["role"]) && $_SESSION["role"] === "pegawai"){?>
                <button class="btn btn-red m-0" type="button" style="border: none;" data-bs-toggle="offcanvas" data-bs-target="#leftbar"><i class="fa-solid fa-bars"></i></button>
              <?php }?>
              <div class="input-group input_bar ms-2 me-2">
                <input type="text" class="form-control" placeholder="Cari Pertanyaan" aria-label="Recipient's username" aria-describedby="button-addon2" <?php (isset($_SESSION["role"]) && $_SESSION["role"] == "pegawai")?$bidang = $data['profil']['instansi']:$bidang = ""?> onkeyup="caripertanyaan(this.value,<?=$bidang?>)">
                <button class="btn btn-light" style="background: white;" type="button" id="button-addon2"><i class="fa-solid fa-magnifying-glass"></i></button>
              </div>
              <?php if(isset($_SESSION["role"]) && $_SESSION["role"] === "admin"){?>
                <a href="<?=BASEURL?>/Master" class="btn btn-red" type="button" style="border: none;"><i class="fa-solid fa-user-tie"></i></a>
              <?php }?>
              <button <?php isset($_SESSION["login"])?$form = "formSign3":$form = "formSign"?> data-bs-target="#<?=$form?>" data-bs-toggle="modal" class="btn btn-red" type="button" style="border: none;"><i class="fa-regular fa-user"></i></button>
              <?php if(isset($_SESSION["login"])){?>
                <a href="<?=BASEURL?>/Logout" class="btn btn-green" type="button" style="border: none;" ><i class="fa fa-sign-out"></i></i></a>
              <?php }?>
            </div>
          </div>
        </nav>
        <!-- pencarian -->
        <h1 style="padding-left: 20px; margin:0 0 10px 0; font-family:Grand Hotel;"><?=$data["title_question"]?></h1>
        <div id="bar_question" class="vertical-scroll" style="height: 60%; padding:20px"></div>
        <!-- form input pertanyaan -->
        <?php if(!isset($_SESSION["login"]) || $_SESSION["role"] == "penanya"){?>
        <div style="width: 100%; padding:5px 0; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.25);">
          <div style="padding: 10px 65px;">
            <form id="question_form" action="<?=BASEURL?>/Pertanyaan/create" method="post" enctype="multipart/form-data">
            <!-- daftar pilihan bidang -->
            <div class="button-content horizontal-scroll pb-2">
              <input type="radio" class="btn-check" name="target_tanya" id="bidang_1" autocomplete="off" value="Perencanaan Anggaran" required>
              <label class="btn btn-outline-primary" for="bidang_1"
                style="--bs-btn-padding-y: .25rem; --bs-btn-padding-x: .5rem; --bs-btn-font-size: .75rem;">
                Perencanaan Anggaran
              </label>

              <input type="radio" class="btn-check" name="target_tanya" id="bidang_2" autocomplete="off" value="Pemberdarahaan Akuntansi dan Pelaporan" required>
              <label class="btn btn-outline-primary" for="bidang_2"
                style="--bs-btn-padding-y: .25rem; --bs-btn-padding-x: .5rem; --bs-btn-font-size: .75rem;">
                Pemberdarahaan Akuntansi dan Pelaporan
              </label>

              <input type="radio" class="btn-check" name="target_tanya" id="bidang_3" autocomplete="off" value="Pengelolaan BMD" required>
              <label class="btn btn-outline-primary" for="bidang_3"
                style="--bs-btn-padding-y: .25rem; --bs-btn-padding-x: .5rem; --bs-btn-font-size: .75rem;">
                Pengelolaan BMD
              </label>

              <input type="radio" class="btn-check" name="target_tanya" id="bidang_4" autocomplete="off" value="Sekertariat BPKAD" required>
              <label class="btn btn-outline-primary" for="bidang_4"
                style="--bs-btn-padding-y: .25rem; --bs-btn-padding-x: .5rem; --bs-btn-font-size: .75rem;">
                Sekertariat BPKAD
              </label>
            </div>
            <!-- button input pertanyaan -->
            <div class="input-group input_bar" style="border-radius: 10px;">
              <textarea type="text" class="form-control" placeholder="Buat Pertanyaan" aria-label="Recipient's username" name="pertanyaan" required></textarea>
              <?php if(isset($_SESSION["login"])){?>
                <!-- jika sudah login -->
                <button class="btn btn-light" style="background: white;" type="submit"><i class="fa-solid fa-paper-plane"></i></button>
              <?php }else{?>
                <!-- jika belum login -->
                <button class="btn btn-light" style="background: white;" type="button" data-bs-target="#formSign" data-bs-toggle="modal"><i class="fa-solid fa-paper-plane"></i></button>
              <?php }?>
            </div>
            <!-- tempat input file -->
            <div class="input-group mt-2">
                <label class="input-group-text" for="inputGroupFile01">Unggah File</label>
                <input type="file" class="form-control" id="inputGroupFile01" name="file">
            </div>
            <!-- input data yang diperlukan tanpa ditampilkan -->
            <input type="hidden" name="id_p" value="<?=$data["profil"]["id_p"]?>">
            <input type="hidden" name="penanya" value="<?=$data["profil"]["nama"]?>">
            <input type="hidden" name="instansi" value="<?=$data["profil"]["instansi"]?>">
            </form>
          </div>
        </div>
        <?php }?>
      </div>
      <!-- akhir main content -->
    </div>
  </div>
  
  <!-- modal untuk form jawaban -->
  <div class="modal fade" id="formJawaban" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-body position-relative pb-0">
          <button type="button" class="btn-close position-absolute top-0 end-0 m-3" data-bs-dismiss="modal" aria-label="Close"></button>
          <h5 class="modal-title tittle-bar" id="staticBackdropLabel">Form Jawaban</h5>
          <div class="p-3" style="background: linear-gradient(0deg, rgba(193, 64, 64, 0.95), rgba(193, 64, 64, 0.95)), url(https://i.pinimg.com/564x/41/75/89/417589977935a69806102c96c8da09dc.jpg); 
          text-align:center; background-size:cover; border-radius:7px;">
            <div style="background-color: #fff; text-align:left; padding:20px 10px; margin-bottom:10px; border-radius:10px">
              <h4 style="font-size: 14pt;" id="identitas">Nama Penanya - Instansi/Bidang</h4>
              <p style="font-size: 10pt;" id="pertanyaan">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>
            </div>
            <form id="jawab_form" role="form" action="<?=BASEURL?>/Pertanyaan/jawab" method="post" enctype="multipart/form-data">
              <input type="hidden" name="id_q" id="id_question">
              <input type="hidden" name="penjawab" value="<?=$data["profil"]["nama"]?>">
              <input type="hidden" name="id_penjawab" value="<?=$data["profil"]["id_p"]?>">
              <div class="form-floating">
                <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px" name="jawaban" required></textarea>
                <label for="floatingTextarea2">Jawaban Pertanyaan</label>
              </div>
              <div class="input-group mt-1" id="container_file_jawab" style="display: none;"></div>
              <div class="input-group mt-2">
                <label class="input-group-text" for="inputGroupFile01">Unggah File</label>
                <input type="file" class="form-control" id="inputGroupFile01" name="file_jawab">
              </div>
            </form>
          </div>
        </div>
        <div class="modal-footer button-content" style="border: none; text-align:center">
          <button type="submit" class="btn btn-primary" id="up-submit" form="jawab_form">Kirim Jawaban</button>
        </div>
      </div>
    </div>
  </div>