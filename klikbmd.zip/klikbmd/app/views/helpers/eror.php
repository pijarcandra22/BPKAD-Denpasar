<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="<?=ASSETS?>/image/icon.png" type="image/icon">
    <title>BPKAD Menjawab</title>
</head>
<body>
    <div class="">
        <h1>404 not found</h1>
        <br>
        <hr>
    </div>
</body>
</html>