<?php foreach($data["caripegawai"] as $pegawai):?>
    <div data-bs-target="#formJawaban" data-bs-toggle="modal" class="formnojawab" data-id="<?=$pegawai["id_q"]?>">
        <div style="display: flex; margin: 10px 30px" class="tab_list" id="list_ask">
            <p class="num_or_img">
                <img src="<?=ASSETS?>/image/<?=$pegawai["foto"]?>" alt="gambar" style="width: 100%; height: 100%; border-radius: 50%;">
            </p>
            <div style="display: block; padding-left:10px">
                <p style="font-size: 17px; line-height: 20px; margin:0" class="nama"><?=$pegawai["nama"]?></p>
                <p style="font-size: 10px; line-height: 13px; margin:0" class="ins_or_bidang"><?=$pegawai["instansi"]?></p>
            </div>
        </div>
    </div>
<?php endforeach;?>