<div class="container-fluid background p-4">
    <h1 class="p-4 d-md-none" style="text-align:center; font-size:40px; font-family:Grand Hotel; margin:0">Halaman Admin</h1>
    <div class="row justify-content-center">
      <div class="col-12 col-lg-6 row justify-content-center">
        <div class="col-12 col-sm-6">
          <h5 style="width: 100%; background:#C14040;padding:10px; color:#fff; text-align:center; font-family:Grand Hotel; cursor:pointer;" onclick="home()">Klinik Keuangan BMD</h5>
          <div class="input-group input_bar">
            <input type="text" class="form-control" placeholder="Cari Pegawai" aria-label="Recipient's username" aria-describedby="button-addon2" onkeyup="cari_pegawai(this.value)">
            <button class="btn btn-light" style="background: white;" type="button" id="send_quest"><i class="fa-solid fa-magnifying-glass"></i></button>
          </div>
          <div class="button-content horizontal-scroll p-2" style="text-align: center;">
            <input type="radio" class="btn-check" name="target_tanya" id="bidang_1" autocomplete="off" value="Perencanaan Anggaran">
            <label class="btn btn-outline-primary" for="bidang_1"
              style="--bs-btn-padding-y: .25rem; --bs-btn-padding-x: .5rem; --bs-btn-font-size: .75rem;" onclick="cari_bidang('Perencanaan Anggaran')">
              Perencanaan Anggaran
            </label>

            <input type="radio" class="btn-check" name="target_tanya" id="bidang_2" autocomplete="off" value="Bidang 2">
            <label class="btn btn-outline-primary" for="bidang_2"
              style="--bs-btn-padding-y: .25rem; --bs-btn-padding-x: .5rem; --bs-btn-font-size: .75rem;" onclick="cari_bidang('Pemberdarahaan Akuntansi dan Pelaporan')">
              Pemberdarahaan Akuntansi dan Pelaporan
            </label>

            <input type="radio" class="btn-check" name="target_tanya" id="bidang_3" autocomplete="off" value="Bidang 3">
            <label class="btn btn-outline-primary" for="bidang_3"
              style="--bs-btn-padding-y: .25rem; --bs-btn-padding-x: .5rem; --bs-btn-font-size: .75rem;" onclick="cari_bidang('Pengelolaan BMD')">
              Pengelolaan BMD
            </label>

            <input type="radio" class="btn-check" name="target_tanya" id="bidang_4" autocomplete="off" value="Bidang 4">
            <label class="btn btn-outline-primary" for="bidang_4"
              style="--bs-btn-padding-y: .25rem; --bs-btn-padding-x: .5rem; --bs-btn-font-size: .75rem;" onclick="cari_bidang('Sekertariat BPKAD')">
              Sekertariat BPKAD
            </label>
          </div>
          <div id="belum_jawab" class="vertical-scroll">
          <?php foreach($data["pegawai"] as $pegawai):?>
            <div data-bs-target="#formSign3" data-bs-toggle="modal" class="pegawaiprofil" data-id="<?=$pegawai["id_p"]?>">
            <div style="display: flex; margin: 10px 30px" class="tab_list" id="list_ask">
              <p class="num_or_img">
                <img src="<?=ASSETS?>/image/<?=$pegawai["foto"]?>" alt="gambar" style="width: 100%; height: 100%; border-radius: 50%;">
              </p>
              <div style="display: block; padding-left:10px">
                <p style="font-size: 17px; line-height: 20px; margin:0" class="nama"><?=$pegawai["nama"]?></p>
                <p style="font-size: 10px; line-height: 13px; margin:0" class="ins_or_bidang"><?=$pegawai["instansi"]?></p>
              </div>
            </div>
            </div>
          <?php endforeach;?>
          </div>
        </div>
        <div class="col-12 col-sm-6">
          <h1 class="p-2" style="text-align:center; font-family:Grand Hotel">Halaman Admin</h1>
          <div style="background: linear-gradient(0deg, rgba(193, 64, 64, 0.95), rgba(193, 64, 64, 0.95)), url(https://i.pinimg.com/564x/41/75/89/417589977935a69806102c96c8da09dc.jpg); text-align:center; border-radius:20px !important;" class="p-4">
            <div class="d-flex" style="width: 100%;">
              <div style="width: 33.3%; background-size:cover;"></div>
              <div style="width: 33.3%; background-size:cover;"><h5 style="color: #fff; font-family:Grand Hotel"><?=$data["performa"][0]["nama"]?>1</h5></div>
              <div style="width: 33.3%; background-size:cover;"></div>
            </div>
            <div class="d-flex" style="height: 40px; width: 100%;">
              <div style="width: 33.3%; background-size:cover; height:100%"></div>
              <div style="width: 33.3%; background-size:cover; background-color:rgba(255, 255, 255); height:100%"></div>
              <div style="width: 33.3%; background-size:cover; height:100%"><h5 style="color: #fff; font-family:Grand Hotel"><?=$data["performa"][1]["nama"]?>2</h5></div>
            </div>
            <div class="d-flex" style="height: 40px; width: 100%;">
              <div style="width: 33.3%; background-size:cover; height:100%"><h5 style="color: #fff; font-family:Grand Hotel" ><?=$data["performa"][2]["nama"]?>3</h5></div>
              <div style="width: 33.3%; background-size:cover; background-color:rgba(255, 255, 255); height:100%"></div>
              <div style="width: 33.3%; background-size:cover; background-color:rgba(255, 255, 255, 0.87); height:100%"></div>
            </div>
            <div class="d-flex barchart" style="width: 100%;">
              <div class="position-relative" style="width: 33.3%; background-size:cover; background-color:rgba(255, 255, 255, 0.47);">
                <div class="position-absolute top-50 start-50 translate-middle" style="background:#C14040; border-radius:50%">
                  <p class="rekor_val"><img src="<?=BASEURL?>/app/assets/image/<?=$data["performa"][2]["foto"]?>" style="border-radius: 50%; width:100%"></p>
                </div>
              </div>
              <div class="position-relative" style="width: 33.3%; background-size:cover; background-color:rgba(255, 255, 255);">
                <div class="position-absolute top-50 start-50 translate-middle" style="background:#C14040; border-radius:50%">
                  <p class="rekor_val"><img src="<?=BASEURL?>/app/assets/image/<?=$data["performa"][0]["foto"]?>" style="border-radius: 50%; width:100%"></p>
                </div>
              </div>
              <div class="position-relative" style="width: 33.3%; background-size:cover; background-color:rgba(255, 255, 255, 0.87);">
                <div class="position-absolute top-50 start-50 translate-middle" style="background:#C14040; border-radius:50%">
                  <p class="rekor_val"><img src="<?=BASEURL?>/app/assets/image/<?=$data["performa"][1]["foto"]?>" style="border-radius: 50%; width:100%"></p>
                </div>
              </div>
            </div>            
          </div>
          <div id="question_all" class="vertical-scroll question_pop p-2">
            <?php foreach($data["rating"] as $rating):?>
            <div class="question mt-2">
              <h4><?=$rating["tujuan"]?></h4>
              <p>
                <?php if(!empty($rating["rating"])){?>
                <?php for($i = 1; $i <= $rating["rating"]; $i++){?>
                  <span class="fa fa-star" style="color: rgb(255, 255, 0)"></span>
                <?php }?>
                <?php for($i = $rating["rating"]+1; $i <= 5; $i++){?>
                  <span class="fa fa-star"></span>
                <?php }?>
                <?php }else{?>
                  <span class="fa fa-star"></span>
                  <span class="fa fa-star"></span>
                  <span class="fa fa-star"></span>
                  <span class="fa fa-star"></span>
                  <span class="fa fa-star"></span>
                <?php }?>
              </p>
            </div>
            <?php endforeach;?>
          </div>
        </div>
      </div>
      <div class="col-12 col-lg-6 row justify-content-center">
        <?php for($i = 0; $i < 4 ; $i++):?>
        <?php $data_persen = $data["perbidang"][$data["bidang"][$i]];?>
        <?php if(sizeof($data_persen) > 1) {?>
        <div class="col-12 col-sm-5 position-relative m-2" style="background:linear-gradient(0deg, rgba(193, 64, 64, 0.95), rgba(193, 64, 64, 0.95)), url(https://i.pinimg.com/564x/41/75/89/417589977935a69806102c96c8da09dc.jpg); border-radius: 20px;">
          <div style="margin:20px 10px">
            <div style="font-size: 12px; color:#fff"><i class="fa-solid fa-square"></i> Sudah Terjawab</div>
            <div style="font-size: 12px; color:#f5b5b5"><i class="fa-solid fa-square"></i> Belum Terjawab</div>
          </div>
          
          <div class="position-absolute top-50 start-50 translate-middle position-relative" style="background: conic-gradient(#f5b5b5 0 <?=$data_persen[0]?>%, #fff 0 <?=$data_persen[1]?>%); height:150px; width: 150px; border-radius:50%">
            <div class="position-absolute top-50 start-50 translate-middle" style="background:#C14040; border-radius:50%">
              <p style="font-size: 50px; color:#fff; margin:0; line-height:120px; width: 120px; text-align:center"><img src="<?=BASEURL?>/app/assets/image/profil.png" style="border-radius: 50%; width:100%"></p>
            </div>
          </div>
          <h5 style="text-align:center; margin-top:200px; color:#fff;"><?=$data["bidang"][$i]?></h5>
        </div>
        <?php }else{?>
          <div class="col-12 col-sm-5 position-relative m-2" style="background:linear-gradient(0deg, rgba(193, 64, 64, 0.95), rgba(193, 64, 64, 0.95)), url(https://i.pinimg.com/564x/41/75/89/417589977935a69806102c96c8da09dc.jpg); border-radius: 20px;">
          <div style="margin:20px 10px">
            <div style="font-size: 12px; color:#B9B7BD"><i class="fa-solid fa-square"></i> Tidak Ada Pertanyaan</div>
          </div>
          <div class="position-absolute top-50 start-50 translate-middle position-relative" style="background: conic-gradient(#B9B7BD 100%, #fff 0%); height:150px; width: 150px; border-radius:50%">
            <div class="position-absolute top-50 start-50 translate-middle" style="background:#C14040; border-radius:50%">
              <p style="font-size: 50px; color:#fff; margin:0; line-height:120px; width: 120px; text-align:center"><img src="<?=BASEURL?>/app/assets/image/profil.png" style="border-radius: 50%; width:100%"></p>
            </div>
          </div>
          <h5 style="text-align:center; margin-top:250px; color:#fff; vertical-align: center;"><?=$data["bidang"][$i]?></h5>
        </div>
        <?php }?>
        <?php endfor;?>
      </div>
    </div>
  </div>

  <!-- form profil pegawai -->
  <div class="modal fade" id="formSign3" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-body position-relative pb-0" style="padding-top: 100px;">
        <button type="button" class="btn-close position-absolute top-0 end-0 m-3" data-bs-dismiss="modal" aria-label="Close"></button>
        <label for="img_user" class="position-absolute top-0 start-50 translate-middle position-relative" id="img_user_label">
          <div class="position-absolute bottom-0 start-50 translate-middle-x">
            <i class="fa-solid fa-camera"></i>
          </div>
        </label>
        <h5 class="modal-title tittle-bar" id="staticBackdropLabel">Profil Pengguna</h5>
        <div class="p-3" style="background: linear-gradient(0deg, rgba(193, 64, 64, 0.95), rgba(193, 64, 64, 0.95)), url(https://i.pinimg.com/564x/41/75/89/417589977935a69806102c96c8da09dc.jpg); 
        text-align:center; background-size:cover; border-radius:7px;">
          <form id="update_form" role="form" >
            <input class="form-control mt-2" type="text" placeholder="Nama Lengkap" name="nama" id="namaprofil" disabled>
            <input class="form-control mt-2" type="text" placeholder="Instansi" name="instansi" id="instansiprofil" disabled>
            <input class="form-control mt-2" type="text" placeholder="Email" name="email" id="emailprofil" disabled>
          </form>
        </div>
      </div>
      <div class="modal-footer button-content" style="border: none; text-align:center">
      </div>
    </div>
  </div>
</div>