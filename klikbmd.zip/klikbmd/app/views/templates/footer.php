<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script>
</body>
</html>
<script src="<?=ASSETS?>/js/<?=$data['js']?>.js"></script>
<?php if(isset($_SESSION["role"]) && $_SESSION["role"] === "penanya"){ ?>
  <script src="app/assets/js/make_rating.js"></script>
<?php }?>