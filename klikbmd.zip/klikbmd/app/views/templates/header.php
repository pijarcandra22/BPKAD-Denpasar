<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BPKAD Menjawab</title>
  <link rel="icon" href="<?=ASSETS?>/image/icon.png" type="image/icon">
  <!--Bootstrap-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
  
  <!--Google Font-->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Grand+Hotel&family=Roboto:wght@100;300;400;500;700&display=swap" rel="stylesheet">
  
  <!--Font Awesome-->
  <script src="https://kit.fontawesome.com/5eff079939.js" crossorigin="anonymous"></script>

  <!--Local CSS-->
  <link href="<?=ASSETS?>/css/landing.css" rel="stylesheet">
  <link href="<?=ASSETS?>/css/<?=$data['css']?>.css" rel="stylesheet">
</head>
<body class="background">