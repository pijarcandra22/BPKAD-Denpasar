<?php if(!empty($data["pertanyaan"])){?>
  <?php foreach($data["pertanyaan"] as $p_b):?>
  <div class="question_pop">
    <div class="question position-relative" style="text-align: left;">
      <h4><?=$p_b["penanya"]?> - <?=$p_b["instansi"]?></h4>
      <p>
        <?=$p_b["pertanyaan"]?>
        <a href="<?=BASEURL?>/Assets/upload/<?=$p_b["file"]?>" target="blank"><?php !empty($p_b["file"])?$label = "files":$label = ""; echo $label?></a>
      </p>
    </div>
    <?php if($p_b["jawaban"] != ""){?>
    <div class="answeer position-relative">
      <div style="text-align: left;">
        <h6 style="display: inline-block;"><?=$p_b["penjawab"]?> - BPKAD/<?=$p_b["tujuan"]?></h6>
        <div style=" font-size:10pt; display: inline-block; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.25); padding:2px 10px; border-radius:30px; color:#C14040; background-color:white">
          <?php if(!empty($p_b["rating"])){?>
          <?php for($i = 1; $i <= $p_b["rating"]; $i++){?>
            <span class="fa fa-star star_<?=$i?><?=$p_b['id_q']?>" onclick="rating(<?=$p_b['id_q']?>,<?=$i?>)" style="color: rgb(255, 255, 0)"></span>
          <?php }?>
          <?php for($i = $p_b["rating"]+1; $i <= 5; $i++){?>
            <span class="fa fa-star star_<?=$i?><?=$p_b['id_q']?>" onclick="rating(<?=$p_b['id_q']?>,<?=$i?>)"></span>
          <?php }?>
          <?php }else{?>
            <span class="fa fa-star star_1<?=$p_b['id_q']?>" onclick="rating(<?=$p_b['id_q']?>,1)"></span>
            <span class="fa fa-star star_2<?=$p_b['id_q']?>" onclick="rating(<?=$p_b['id_q']?>,2)"></span>
            <span class="fa fa-star star_3<?=$p_b['id_q']?>" onclick="rating(<?=$p_b['id_q']?>,3)"></span>
            <span class="fa fa-star star_4<?=$p_b['id_q']?>" onclick="rating(<?=$p_b['id_q']?>,4)"></span>
            <span class="fa fa-star star_5<?=$p_b['id_q']?>" onclick="rating(<?=$p_b['id_q']?>,5)"></span>
          <?php }?>
        </div>
      </div>
      <p><?=$p_b["jawaban"]?>
      <a href="<?=BASEURL?>/Assets/upload/<?=$p_b["file_jawaban"]?>" target="blank"><?php !empty($p_b["file_jawaban"])?$label = "files":$label = ""; echo $label?></a>
      </p>
      <?php if(isset($_SESSION["role"]) && $_SESSION["role"] === "pegawai"){?>
      <div class="position-absolute top-100 translate-middle" style="width:max-content; left:80%">
        <button class="btn btn-light btn-sm nojawab" data-bs-target="#formJawaban" data-bs-toggle="modal" onclick="editjawaban(<?=$p_b['id_q']?>)">Edit</button>
        <button class="btn btn-light btn-sm hapusjawaban" onclick="hapusjawaban(<?=$p_b['id_q']?>)">Hapus</button>
      </div>
      <?php }?>
    </div>
    <?php }?>
  </div>
  <?php endforeach;?>
<?php }else{?>
  <div class="question_pop">
    <?php if(isset($_SESSION["login"]) && $_SESSION["role"] != "admin"){?>
    <?php $_SESSION["role"] == "pegawai"?$notif = $data["profil"]["instansi"]:$notif =  $data["profil"]["nama"]?>
    <?php $data["profil"]["nama"]?>
    <p>Saat ini belum ada pertanyaan untuk <?=$notif?></p>
    <?php }else{?>
      <p>saat ini belum ada faq</p>
    <?php }?>
  </div>
<?php }?>