<div class="modal fade" id="formSign" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-body position-relative pb-0">
        <button type="button" class="btn-close position-absolute top-0 end-0 m-3" data-bs-dismiss="modal" aria-label="Close"></button>
        <h5 class="modal-title tittle-bar" id="staticBackdropLabel">Sign In</h5>
        <div class="p-3" style="background: linear-gradient(0deg, rgba(193, 64, 64, 0.95), rgba(193, 64, 64, 0.95)), url(https://i.pinimg.com/564x/41/75/89/417589977935a69806102c96c8da09dc.jpg); 
        text-align:center; background-size:cover; border-radius:7px;">
          <form id="signin_form" action="<?=BASEURL?>/Session" method="post">
            <input class="form-control" type="text" placeholder="NIP/ID" required name="nip">
            <input class="form-control mt-2" type="password" placeholder="Password" required name="pass_in">
          </form>
        </div>
      </div>
      <div class="modal-footer button-content" style="border: none; text-align:center">
        <button type="button" class="btn btn-outline-primary" data-bs-target="#formSign2" data-bs-toggle="modal">Sign Up</button>
        <button type="submit" class="btn btn-primary" id="in-submit" form="signin_form">Sign In</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="formSign2" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="alert " role="alert" style="display: none;">
        Re-pssword masih salah
      </div>
      <div class="modal-body position-relative pb-0">
        <button type="button" class="btn-close position-absolute top-0 end-0 m-3" data-bs-dismiss="modal" aria-label="Close"></button>
        <h5 class="modal-title tittle-bar" id="staticBackdropLabel">Sign Up</h5>
        <div class="p-3" style="background: linear-gradient(0deg, rgba(193, 64, 64, 0.95), rgba(193, 64, 64, 0.95)), url(https://i.pinimg.com/564x/41/75/89/417589977935a69806102c96c8da09dc.jpg); 
        text-align:center; background-size:cover; border-radius:7px;">
          <form id="signup_form" action="<?=BASEURL?>/Signup/daftar" method="post">
            <input type="hidden" name="role" value="penanya">
            <input type="hidden" name="foto" value="profil.png">
            <input class="form-control mt-2" type="text" placeholder="Nama Lengkap" name="nama" required>
            <input class="form-control mt-2" type="text" placeholder="NIP / ID" name="nip" reuired>
            <input class="form-control mt-2" type="text" placeholder="Instansi" name="instansi" required>
            <input class="form-control mt-2" type="text" placeholder="Email" name="email" required>
            <input class="form-control mt-2" type="password" placeholder="Password" name="pass_up" id="pass_up" required>
            <input class="form-control mt-2" type="password" placeholder="Re-Password" id="repass_up" required>
        </div>
      </div>
      <div class="modal-footer button-content" style="border: none; text-align:center">
        <button type="button" class="btn btn-outline-primary" data-bs-target="#formSign" data-bs-toggle="modal">Sign In</button>
        <button type="submit" class="btn btn-primary" form="signup_form">Sign Up</button>
        </form>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="formSign3" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-body position-relative pb-0" style="padding-top: 100px;">
        <button type="button" class="btn-close position-absolute top-0 end-0 m-3" data-bs-dismiss="modal" aria-label="Close"></button>
        <label for="img_user" class="position-absolute top-0 start-50 translate-middle position-relative" id="img_user_label" style="background-image: url(<?=ASSETS?>/image/<?=$data["profil"]["foto"]?>)">
          <div class="position-absolute bottom-0 start-50 translate-middle-x">
            <i class="fa-solid fa-camera"></i>
          </div>
        </label>
        <h5 class="modal-title tittle-bar" id="staticBackdropLabel">Profil Pengguna</h5>
        <div class="p-3" style="background: linear-gradient(0deg, rgba(193, 64, 64, 0.95), rgba(193, 64, 64, 0.95)), url(https://i.pinimg.com/564x/41/75/89/417589977935a69806102c96c8da09dc.jpg); 
        text-align:center; background-size:cover; border-radius:7px;">
          <form id="update_form" role="form" action="<?=BASEURL?>/Home/ubah" method="post" enctype="multipart/form-data">
            <input type="file" id="img_user" style="display: none;" name="gambar" value="<?=$data["profil"]["foto"]?>">
            <input type="hidden" value="<?=$data["profil"]["id_p"]?>" name="id_p">
            <input class="form-control mt-2" type="text" placeholder="Nama Lengkap" name="nama" value="<?=$data["profil"]["nama"]?>">
            <input class="form-control mt-2" type="text" placeholder="Instansi" name="instansi" value="<?=$data["profil"]["instansi"]?>">
            <input class="form-control mt-2" type="text" placeholder="Email" name="email" value="<?=$data["profil"]["email"]?>">
          </form>
        </div>
      </div>
      <div class="modal-footer button-content" style="border: none; text-align:center">
        <?php if(isset($_SESSION["role"]) && $_SESSION["role"] == "penanya"){?>
          <button type="button" class="btn btn-outline-primary" data-bs-dismiss="modal">Pertanyaan Saya</button>
        <?php }?>
        <button type="submit" class="btn btn-primary" id="up-submit" form="update_form">Update</button>
      </div>
    </div>
  </div>
</div>
<script>
  $("#repass_up").on('keyup', function(){
    if($("#pass_up").val() === $("#repass_up").val()){
      $(".alert").css("display","none");
    }else{
      $(".alert").css("display","block");
    }
  });
  $("#img_user").change(function() {
    $("#img_user_label").css({"background-image":"url("+URL.createObjectURL(document.getElementById('img_user').files[0])+")"})
  });
</script>