<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="<?=ASSETS?>/image/icon.png" type="image/icon">
    <title>BPKAD Menjawab</title>
</head>
<body>
    <?php if(in_array($data["tipe"], ["png","jpg","jpeg","gif"])){?>
        <img src="<?=BASEURL?>/app/assets/file/<?=$data["src"]?>">
    <?php }else{?>
        <iframe src="<?=BASEURL?>/app/assets/file/<?=$data["src"]?>" frameborder="0" style="width:100%; height:100vh"></iframe>
    <?php };?>
</body>
</html>