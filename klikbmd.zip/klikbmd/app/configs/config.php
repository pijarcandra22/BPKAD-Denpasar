<?php
define('BASEURL', 'http://localhost/klikbmd');
define('ASSETS', 'app/assets');

//database
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','portal');