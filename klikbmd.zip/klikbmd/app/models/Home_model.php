<?php

class Home_model {
    private $db;
    public function __construct()
    {
        $this->db = new Database;
    }
    public function get_profil($id)
    {
        $query = "SELECT * FROM pengguna WHERE id_p = :id_p";
        $this->db->query($query);
        $this->db->bind("id_p", $id);
        return $this->db->single();
    }
    public function ubah_profil($data,$file){
        $nama_file = $file["gambar"]["name"];
        $tipe_file = explode(".",$nama_file);
        $tipe_file = end($tipe_file);
        $tipe_file = strtolower($tipe_file);
        $ukuran_file = $file["gambar"]["size"];
        $error = $file["gambar"]["error"];
        $tmp_name = $file["gambar"]["tmp_name"];

        //cek apakah file yang diupload ada, berekstensi jpg,png,jpeg,dan berukuran 2 MB
        if($error === 4 && !in_array($tipe_file, ["jpg", "jpeg", "png"]) && $ukuran_file > 2000000){
            $data["foto"] = $data["gambar"];
        }else{
            $data["foto"]= time().".".$tipe_file;
            move_uploaded_file($tmp_name,"app/assets/image/".$data["foto"]);
        }
        
        $query = "UPDATE pengguna SET
        nama = :nama,
        instansi = :instansi,
        email = :email,
        foto = :foto
        WHERE id_p = :id_p";
        $this->db->query($query);
        $this->db->bind("nama", $data["nama"]);
        $this->db->bind("instansi", $data["instansi"]);
        $this->db->bind("email", $data["email"]);
        $this->db->bind("id_p", $data["id_p"]);
        $this->db->bind("foto", $data["foto"]);
        $this->db->execute();
        return $this->db->rowCount();
    }
    public function get_pertanyaan_by_from($id)
    {
        $this->db->query("SELECT * FROM pertanyaan WHERE id_p = :id_p");
        $this->db->bind("id_p", $id);
        return $this->db->resultSet();
    }
    public function get_pertanyaan_by_bidang($bidang)
    {
        $this->db->query("SELECT * FROM pertanyaan WHERE tujuan = :bidang");
        $this->db->bind("bidang", $bidang);
        return $this->db->resultSet();
    }
    public function get_id_pertanyaan($idq)
    {
        $this->db->query("SELECT * FROM pertanyaan WHERE id_q = :id_q");
        $this->db->bind("id_q", $idq);
        return $this->db->Single();
    }
}