<?php

class Session_model {
    private $db;

    public function __construct()
    {
        $this->db = new Database;
    }
    public function login($data)
    {
        $data["nip"] = htmlspecialchars($data["nip"]);
        $data["pass_in"] = htmlspecialchars($data["pass_in"]);
        $query = "SELECT * FROM pengguna WHERE nip = :nip";
        $this->db->query($query);
        $this->db->bind("nip", $data["nip"]);
        $data_login = $this->db->single();
        if(!empty($data_login)){
            if($data["pass_in"] === $data_login["pasword"]){
                return $data_login;
            }else{
                return [];
            }
        }else{
            return [];
        }
    }
}