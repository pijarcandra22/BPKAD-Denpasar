<?php

class Master_model {
    private $db;
    public function __construct()
    {
        $this->db = new Database;
    }
    public function get_all_pegawai()
    {
        $this->db->query("SELECT * FROM pengguna WHERE role = 'pegawai' ");
        return $this->db->resultSet();
    }
}