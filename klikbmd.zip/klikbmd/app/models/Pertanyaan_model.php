<?php
class Pertanyaan_model {
    private $db;
    public function __construct()
    {
        $this->db = new Database;
    }
    public function create($data,$file)
    {
        $nama_file = $file["file"]["name"];
        $tipe_file = explode(".",$nama_file);
        $tipe_file = end($tipe_file);
        $tipe_file = strtolower($tipe_file);
        $ukuran_file = $file["file"]["size"];
        $error = $file["file"]["error"];
        $tmp_name = $file["file"]["tmp_name"];
        $data["pertanyaan"] = htmlspecialchars($data["pertanyaan"]);
        if($error === 4){
            $data["file"] = "";
        }else{
            $data["file"] = time().".".$tipe_file;
            move_uploaded_file($tmp_name, "app/assets/file/".$data["file"]);
        }
        $query = "INSERT INTO pertanyaan 
        VALUES('', :id_p, :pertanyaan,'', :namafile, :tujuan,:penanya,'','',:instansi,'')";
        $this->db->query($query);
        $this->db->bind("id_p", $data["id_p"]);
        $this->db->bind("pertanyaan", $data["pertanyaan"]);
        $this->db->bind("namafile", $data["file"]);
        $this->db->bind("tujuan", $data["target_tanya"]);
        $this->db->bind("penanya", $data["penanya"]);
        $this->db->bind("instansi", $data["instansi"]);
        $this->db->execute();
        return $this->db->rowCount();
    }
    public function get_faq()
    {
        $this->db->query("SELECT * FROM pertanyaan limit 10");
        return $this->db->resultSet();
    }
    public function jawab($data,$file)
    {
        $nama_file = $file["file_jawab"]["name"];
        $tipe_file = explode(".",$nama_file);
        $tipe_file = end($tipe_file);
        $tipe_file = strtolower($tipe_file);
        $ukuran_file = $file["file_jawab"]["size"];
        $error = $file["file_jawab"]["error"];
        $tmp_name = $file["file_jawab"]["tmp_name"];
        $data["jawaban"] = htmlspecialchars($data["jawaban"]);
        if($error === 4){
            $data["file_jawaban"] = "";
        }else{
            $data["file_jawaban"] = time().".".$tipe_file;
            move_uploaded_file($tmp_name, "app/assets/file/".$data["file_jawaban"]);
        }
        $query = "UPDATE pertanyaan 
        SET jawaban = :jawaban,
            penjawab = :penjawab,
            file_jawaban = :file_jawaban,
            id_penjawab = :id_penjawab
            WHERE id_q = :id_q
            ";
        $this->db->query($query);
        $this->db->bind("id_q", $data["id_q"]);
        $this->db->bind("jawaban", $data["jawaban"]);
        $this->db->bind("file_jawaban", $data["file_jawaban"]);
        $this->db->bind("penjawab", $data["penjawab"]);
        $this->db->bind("id_penjawab", $data["id_penjawab"]);
        $this->db->execute();
        return $this->db->rowCount();
    }
    public function hapus_jawaban($idq)
    {
        $this->db->query("DELETE FROM pertanyaan WHERE id_q = :idq");
        $this->db->bind("idq", $idq);
        $this->db->execute();
        return $this->db->rowCount();
    }
    public function update_rating($data)
    {
        $query = "UPDATE pertanyaan 
        SET rating = :rating
            WHERE id_q = :idq
            ";
        $this->db->query($query);
        $this->db->bind("idq", $data["idq"]);
        $this->db->bind("rating", $data["rating"]);
        $this->db->execute();
        return $this->db->rowCount();
    }
    public function cari_pertanyaan($data)
    {
        
        if(isset($_POST["keyword"])){
            $keyword = $data["keyword"];
            if(isset($_SESSION["login"])){
                if($_SESSION["role"] == "penanya"){
                    $query = "SELECT * FROM pertanyaan WHERE 
                    (pertanyaan LIKE :keyword OR
                    jawaban LIKE :keyword OR
                    tujuan LIKE :keyword OR
                    penanya LIKE :keyword OR
                    penjawab LIKE :keyword OR
                    instansi LIKE :keyword) AND id_p = :id_p";
                    $this->db->query($query);
                    $this->db->bind("keyword", "%$keyword%");
                    $this->db->bind("id_p", $_SESSION["id_p"]);
                }else if($_SESSION["role"] == "pegawai"){
                    $query = "SELECT * FROM pertanyaan WHERE 
                    (pertanyaan LIKE :keyword OR
                    jawaban LIKE :keyword OR
                    tujuan LIKE :keyword OR
                    penanya LIKE :keyword OR
                    penjawab LIKE :keyword OR
                    instansi LIKE :keyword) AND tujuan = :tujuan";
                    $this->db->query($query);
                    $this->db->bind("keyword", "%$keyword%");
                    $this->db->bind("tujuan", $data["bidang"]);
                }else{
                    $query = "SELECT * FROM pertanyaan WHERE 
                    pertanyaan LIKE :keyword OR
                    jawaban LIKE :keyword OR
                    tujuan LIKE :keyword OR
                    penanya LIKE :keyword OR
                    penjawab LIKE :keyword OR
                    instansi LIKE :keyword";
                    $this->db->query($query);
                    $this->db->bind("keyword", "%$keyword%");
                }
            }else{
                $query = "SELECT * FROM pertanyaan WHERE 
                    pertanyaan LIKE :keyword OR
                    jawaban LIKE :keyword OR
                    tujuan LIKE :keyword OR
                    penanya LIKE :keyword OR
                    penjawab LIKE :keyword OR
                    instansi LIKE :keyword";
                    $this->db->query($query);
                    $this->db->bind("keyword", "%$keyword%");
            }
        }else{
            $query = "SELECT * FROM pertanyaan";
            $this->db->query($query);
        }
        return $this->db->resultSet();
    }
}