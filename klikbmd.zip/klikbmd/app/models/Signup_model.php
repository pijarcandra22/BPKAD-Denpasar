<?php

class Signup_model {
    private $db;
    public function __construct()
    {
        $this->db = new Database;
    }
    public function tambah_pengguna($data)
    {
        $data['nama'] = htmlspecialchars($data['nama']);
        $data['instansi'] = htmlspecialchars($data['instansi']);
        $data['nip'] = htmlspecialchars($data['nip']);
        $data['email'] = htmlspecialchars($data['email']);
        $data['pasword'] = htmlspecialchars($data['pass_up']);

        $query = "INSERT INTO pengguna 
        VALUES('', :nama, :instansi, :nip, :email, :pasword, :roles, :foto)";
        $this->db->query($query);
        $this->db->bind('nama', $data['nama']);
        $this->db->bind('instansi', $data['instansi']);
        $this->db->bind('nip', $data['nip']);
        $this->db->bind('email', $data['email']);
        $this->db->bind('pasword', $data['pass_up']);
        $this->db->bind('roles', $data['role']);
        $this->db->bind('foto', $data['foto']);
        $this->db->execute();
        return $this->db->rowCount();
    }
}