<?php

class Pegawai_model {
    private $db;
    public function __construct()
    {
        $this->db = new Database;
    }
    public function performa()
    {
        $query = "SELECT *, COUNT(id_penjawab) AS jumlah_jawaban FROM pertanyaan WHERE id_penjawab != '' GROUP BY id_penjawab ORDER BY COUNT(id_penjawab) DESC LIMIT 3 ";
        $this->db->query($query);
        $id_performa = $this->db->resultSet();
        $kurang = 3-count($id_performa);

        if($kurang == 3){
            $query = "SELECT id_p FROM pengguna WHERE role = 'pegawai'  LIMIT :kurang ";
            $this->db->query($query);
            $this->db->bind("kurang", $kurang);
            $data_tambahan = $this->db->resultSet();
        }else if($kurang == 2){
            $query = "SELECT id_p FROM pengguna WHERE role = 'pegawai' AND id_p != :id_p  LIMIT :kurang ";
            $this->db->query($query);
            $this->db->bind("kurang", $kurang);
            $this->db->bind("id_p", $id_performa[0]["id_penjawab"]);
            $data_tambahan = $this->db->resultSet();
        }else{
            $query = "SELECT id_p FROM pengguna WHERE role = 'pegawai' AND id_p != :id_p  LIMIT :kurang ";
            $this->db->query($query);
            $this->db->bind("kurang", $kurang);
            $this->db->bind("id_p", $id_performa[0]["id_penjawab"]);
            $this->db->bind("id_p", $id_performa[1]["id_penjawab"]);
            $data_tambahan = $this->db->resultSet();
        }

        $performa_sort = array();
        for($i = 1; $i <= count($id_performa); $i++){
            $performa_sort[$i] = $id_performa[$i-1]["id_penjawab"];
        }
        $j = $i;
        for($i = 0; $i < $kurang; $i++){
            $performa_sort[$j] = $data_tambahan[$i]["id_p"];
            $j+=1;
        }
        $query = "SELECT * FROM pengguna WHERE id_p = :id_p OR id_p = :idp OR id_p = :idp2";
        $this->db->query($query);
        $this->db->bind("id_p", $performa_sort[1]);
        $this->db->bind("idp", $performa_sort[2]);
        $this->db->bind("idp2", $performa_sort[3]);
        return $this->db->resultSet();
    }
    public function perbidang()
    {
        $query = "SELECT tujuan, COUNT(jawaban) AS belum_terjawab FROM pertanyaan WHERE jawaban = '' GROUP BY tujuan";
        $this->db->query($query);
        $belum = $this->db->resultSet();
        
        $query = "SELECT tujuan, COUNT(jawaban) AS sudah_terjawab FROM pertanyaan WHERE jawaban != '' GROUP BY tujuan";
        $this->db->query($query);
        $sudah = $this->db->resultSet();
        //
        $perbidang = array();
        $total = array();
        for($i = 0; $i < count($belum); $i++){
            $total = $belum[$i]["belum_terjawab"] + $sudah[$i]["sudah_terjawab"];
            $persen_belum = (int)(($belum[$i]["belum_terjawab"] * 100)/$total);
            $persen_sudah = (int)(($sudah[$i]["sudah_terjawab"] * 100)/$total);
            $perbidang[$belum[$i]["tujuan"]] = array($persen_belum,$persen_sudah);
        }
        
        $daftar_bidang = ["Perencanaan Anggaran","Pemberdarahaan Akuntansi dan Pelaporan","Pengelolaan BMD","Sekertariat BPKAD"];
        for($j = 0; $j < count($daftar_bidang); $j++){
            if(!in_array($daftar_bidang[$j],array_keys($perbidang))){
                $perbidang[$daftar_bidang[$j]] = array(0);
            }
        }
        return $perbidang;

        // print_r($perbidang);
        // die;

    }
    public function get_rating_per_bidang()
    {
        $query = "SELECT tujuan,rating FROM pertanyaan GROUP BY tujuan";
        $this->db->query($query);
        $rating_bidang = $this->db->resultSet();

        $perbidang = array();
        for($i = 0; $i < count($rating_bidang); $i++){
            $perbidang[] = $rating_bidang[$i]["tujuan"];
        }

        $daftar_bidang = ["Perencanaan Anggaran","Pemberdarahaan Akuntansi dan Pelaporan","Pengelolaan BMD","Sekertariat BPKAD"];
        for($j = 0; $j < count($daftar_bidang); $j++){
            if(!in_array($daftar_bidang[$j],$perbidang)){
                $rating_bidang[$j]["tujuan"] = $daftar_bidang[$j];
                $rating_bidang[$j]["rating"] = 0;
            }
        }

        return $rating_bidang;
    }
    public function cari_bidang($data)
    {
        $query = "SELECT * FROM pengguna WHERE role = 'pegawai' AND instansi = :instansi ";
        $this->db->query($query);
        $this->db->bind("instansi", $data["bidang"]);
        return $this->db->resultSet();
    }
    public function cari_pegawai($keyword)
    {
        $query = "SELECT * FROM pengguna WHERE role = 'pegawai' AND
        (nama LIKE :keyword OR
        instansi LIKE :keyword OR
        nip LIKE :keyword OR
        email LIKE :keyword ) ";
        $this->db->query($query);
        $this->db->bind('keyword', "%$keyword%");
        return $this->db->resultSet();
    }
    public function profil($data)
    {
        $query = "SELECT * FROM pengguna WHERE id_p = :id_p";
        $this->db->query($query);
        $this->db->bind("id_p", $data["idprofil"]);
        return $this->db->single();
    }
}